#!/bin/bash

function log_header() { printf "\033[7;33m  $1         \033[0m\n"; }
function log_info() { printf "\033[7;37m  $1         \033[0m\n"; }
function log_err() { printf "\033[5;31m  $1         \033[0m\n"; }

# detect version
read -d . VERSION < /etc/debian_version

if [ $VERSION == 9 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ stretch main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ stretch main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ stretch-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ stretch-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security stretch/updates main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security stretch/updates main" >> /etc/apt/sources.list
	echo "deb http://ftp.debian.org/debian stretch-backports main" >> /etc/apt/sources.list
	echo "deb-src http://ftp.debian.org/debian stretch-backports main" >> /etc/apt/sources.list

elif [ $VERSION == 10 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ buster main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ buster main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ buster-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ buster-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security buster/updates main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security buster/updates main" >> /etc/apt/sources.list
	echo "deb http://ftp.debian.org/debian buster-backports main" >> /etc/apt/sources.list
	echo "deb-src http://ftp.debian.org/debian buster-backports main" >> /etc/apt/sources.list

elif [ $VERSION == 11 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ bullseye main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bullseye main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ bullseye-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bullseye-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security bullseye-security main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security bullseye-security main" >> /etc/apt/sources.list

elif [ $VERSION == 12 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bookworm main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security bookworm-security main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security bookworm-security main" >> /etc/apt/sources.list

else
	log_err "System is not Debian: $VERSION"
	exit
fi

BACKEND_IP_HARD="194.55.224.46"

if [[ ${BACKEND_IP_HARD:0:1} == "%" ]]; then
	read -p "BACKEND IP: " BACKEND_IP_HARD
else
	log_header "Backend IP hardcoded: $BACKEND_IP_HARD"
fi

apt-get update
apt-get -y upgrade

apachectl stop
apt-get purge apache2
# nginx-full to get usual version with sites-enabled/ directory
apt-get install vim nginx-full openssl e2fsprogs -y --allow-unauthenticated

cd /etc/ssl/ && openssl req -new -x509 -days 1365 -sha1 -newkey rsa:2048 -nodes -keyout server.key -out server.crt -subj '/O=Company/OU=Department/CN=www.example.com'

rm /etc/nginx/sites-enabled/default
cat <<EOT > /etc/nginx/sites-enabled/ssl
server {
	listen 443 default;
	ssl on;
	ssl_certificate /etc/ssl/server.crt; 
	ssl_certificate_key /etc/ssl/server.key;

	server_name _;
	location / {
		access_log off;
		proxy_pass          https://$BACKEND_IP_HARD/;
		proxy_set_header    Host             \$http_host;
		proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
		
		proxy_set_header X-Real-IP \$remote_addr;
		proxy_pass_header Set-Cookie;
		proxy_set_header X-Forwarded-Host \$host;
		proxy_set_header X-Forwarded-Server \$host;
	}
}
EOT

sed -i -r 's/access_log.*/access_log off;/' /etc/nginx/nginx.conf
sed -i -r 's/error_log.*/error_log off;/' /etc/nginx/nginx.conf

ufw allow https
ufw allow 443

service nginx restart

# anon block
sed -i -r 's/auth,authpriv.\*/#auth,authpriv.\*/' /etc/rsyslog.conf ;
service rsyslog restart ;
touch ~/.hushlogin && chattr +i ~/.hushlogin  ;
set +o history; history -c ; echo "set +o history" >> ~/.bashrc ; rm ~/.bash_history ;
rm /var/log/wtmp ;

rm /root/setup_frontend.sh
rm /root/s.sh
rm /root/s
echo "Done!"
echo ""
echo "Verification..."
grep proxy_pass /etc/nginx/sites-enabled/ssl



