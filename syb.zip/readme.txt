cd 
umask 077
mkdir -p .ssh

bunları yaptıktan sonra known_hosts ve authorized keys'i atıyosun .ssh'a