#!/bin/bash

# make ssh
#
# /var/www/html/make_panel_release.sh
# ssh-copy-key root@SERVER_IP
# vim ~/.ssh/config
# scp rlz_0510.zip SERVER_IP:~
# scp /var/www/_SETUP/setup_debian.sh SERVER_IP:~
# ssh xxx
# bash setup.sh


function log_header() { printf "\033[7;33m  $1         \033[0m\n"; }
function log_info() { printf "\033[7;37m  $1         \033[0m\n"; }
function log_err() { printf "\033[5;31m  $1         \033[0m\n"; }

PANEL_ZIP="/root/release.zip"

if [ ! -f $PANEL_ZIP ]; then
	log_err "ZIP $PANEL_ZIP not found"
	exit
fi
 
# detect version
read -d . VERSION < /etc/debian_version

if [ $VERSION == 9 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ stretch main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ stretch main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ stretch-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ stretch-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security stretch/updates main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security stretch/updates main" >> /etc/apt/sources.list
	echo "deb http://ftp.debian.org/debian stretch-backports main" >> /etc/apt/sources.list
	echo "deb-src http://ftp.debian.org/debian stretch-backports main" >> /etc/apt/sources.list

elif [ $VERSION == 10 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ buster main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ buster main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ buster-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ buster-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security buster/updates main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security buster/updates main" >> /etc/apt/sources.list
	echo "deb http://ftp.debian.org/debian buster-backports main" >> /etc/apt/sources.list
	echo "deb-src http://ftp.debian.org/debian buster-backports main" >> /etc/apt/sources.list

elif [ $VERSION == 11 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ bullseye main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bullseye main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ bullseye-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bullseye-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security bullseye-security main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security bullseye-security main" >> /etc/apt/sources.list

elif [ $VERSION == 12 ]; then 
	log_header "Start setup Debian $VERSION"

	echo "deb http://deb.debian.org/debian/ bookworm main contrib non-free" > /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bookworm main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian/ bookworm-updates main contrib non-free" >> /etc/apt/sources.list
	echo "deb http://deb.debian.org/debian-security bookworm-security main" >> /etc/apt/sources.list
	echo "deb-src http://deb.debian.org/debian-security bookworm-security main" >> /etc/apt/sources.list

else 
	log_err "System is not Debian: $VERSION"
	exit
fi

log_header "=============================================================="

#------------------------------------------------------------------------------#
#                   OFFICIAL DEBIAN REPOS                    
#------------------------------------------------------------------------------#


APT_LISTCHANGES_FRONTEND=none
apt-get update && apt-get upgrade -y

apt -y purge nginx
update-alternatives --config php # set 7.4

if [ $VERSION == 9 ]; then 
	log_info "install packages on 9"
	apt-get -y --allow-unauthenticated install apache2 libapache2-mod-php unzip zip vim mc php-mysql php-curl php-mbstring php-gd php-zip curl wget apt-transport-https dirmngr
else
	log_info "install packages on 10+"
	apt-get -y --allow-unauthenticated install php apache2 libapache2-mod-php unzip zip vim mc php-mysql php-curl php-mbstring php-gd php-zip curl wget apt-transport-https dirmngr
fi

if [ $? -ne 0 ]; then
	echo "PACKAGES NOT INSTALLED"
	exit
fi
# Mcrypt built for wrong php version?

#~ vim /etc/php/7.4/cli/php.ini # comment out mcrypt.so
#~ pecl install mcrypt
# uncomment mcrypt.so back
# apt -y --allow-unauthenticated install libapache2-mod-php7.4
# apachectl restart

if [ -d /etc/php/7.4 ]; then
	PHP_VER="7.4"
elif [ -d /etc/php/7.3 ]; then
	PHP_VER="7.3"
elif [ -f /usr/bin/php8.2 ]; then
	PHP_VER="8.2"
else
	echo "setup_debian error: PHP is not found"
	exit 1
fi

apt-cache show php-mcrypt
# install mcrypt    
# OR just copy existing .so
# scp /var/www/octo/setup_scripts/mcrypt.so $USER:/usr/lib/php/20190902/mcrypt.so
# printf "\nextension=mcrypt.so\n" >> /etc/php/$PHP_VER/apache2/php.ini

if [ $? == 0 ]; then 
	log_info "php-mcrypt does not exist"
	apt --allow-unauthenticated -y install php-pear php-dev libmcrypt-dev build-essential
	pecl update
	pecl install mcrypt

	printf "\nextension=mcrypt.so\n" >> /etc/php/$PHP_VER/apache2/php.ini
	printf "\nextension=mcrypt.so\n" >> /etc/php/$PHP_VER/cli/php.ini

fi

###########

sed -i -r "s/memory_limit = 128M/memory_limit = 4096M/" /etc/php/$PHP_VER/apache2/php.ini
sed -i -r "s/upload_max_filesize = 2M/upload_max_filesize = 100M/" /etc/php/$PHP_VER/apache2/php.ini
sed -i -r "s/post_max_size = 8M/post_max_size = 100M/" /etc/php/$PHP_VER/apache2/php.ini

sed -i -r "s/memory_limit = 128M/memory_limit = 4096M/" /etc/php/$PHP_VER/cli/php.ini
sed -i -r "s/upload_max_filesize = 2M/upload_max_filesize = 100M/" /etc/php/$PHP_VER/cli/php.ini
sed -i -r "s/post_max_size = 8M/post_max_size = 100M/" /etc/php/$PHP_VER/cli/php.ini

MYSQL_ROOT_PASS=`date +%s | sha256sum | base64 | head -c 16 ; echo`
echo "MYSQL_ROOT_PASS: $MYSQL_ROOT_PASS"
echo $MYSQL_ROOT_PASS > /var/www/mysql.txt
apt -y --allow-unauthenticated install mariadb-server;
mysql -uroot -e "ALTER USER 'root'@'localhost' IDENTIFIED BY '$MYSQL_ROOT_PASS';flush privileges; exit;"
#mysql -uroot -e "use mysql; UPDATE user SET plugin=''; update user SET PASSWORD=PASSWORD('$MYSQL_ROOT_PASS') WHERE USER='root';flush privileges; exit;"

# CHANGE ROOT PASS: service mysql stop;  mysqld_safe --skip-grant-tables & ; mysql

mkdir /etc/ssl ; cd /etc/ssl/ && openssl req -new -x509 -days 365 -sha1 -newkey rsa:2048 -nodes -keyout server.key -out server.crt -subj '/O=Company/OU=Department/CN=www.example.com'
touch /var/www/apache_error.log
chmod 666 /var/www/apache_error.log
touch /var/www/php-errors.log
chmod 666 /var/www/php-errors.log
chown -R www-data:www-data /var/www/html
a2enmod ssl ; a2enmod rewrite ; apachectl restart

# anonimity
sed -i -r 's/auth,authpriv.\*/#auth,authpriv.\*/' /etc/rsyslog.conf ;
service rsyslog restart ;
touch ~/.hushlogin && chattr +i ~/.hushlogin  ;
rm -f /var/log/wtmp ;


# =============================== SETUP PANEL

unzip $PANEL_ZIP -d /var/www/html
rm $PANEL_ZIP

rm /root/setup_debian.sh
rm /root/setup_frontend.sh

cd /var/www/html

cp tmp/ssl.conf /etc/apache2/sites-enabled/
rm -f /etc/apache2/sites-enabled/000-default.conf
rm -f /etc/apache2/ports.conf
sed -i -r 's/Include ports.conf//' /etc/apache2/apache2.conf
apachectl restart
chown www-data:www-data -R /var/www/html/
echo '<?php header("HTTP/1.0 403 Forbidden");' > /var/www/html/index.php
rm -f /var/www/html/index.html
mv tmp/panel/ .
rm -rf tmp/ *.zip
mv panel/_.htaccess panel/.htaccess


FOLDER=`date +%s | sha256sum | base64 | head -c 16 ; echo`
sleep 1
STATS=`date +%s | sha256sum | base64 | head -c 16 ; echo`
sleep 1
LOGIN=`date +%s | sha256sum | base64 | head -c 16 ; echo`
sleep 1
PASS=`date +%s | sha256sum | base64 | head -c 16 ; echo`

mv panel $FOLDER;
mv $FOLDER/a100 $FOLDER/${LOGIN}adm
mv $FOLDER/stats100 $FOLDER/$STATS

# aliases for fast scp update
ln -s /var/www/html/$FOLDER/ /var/www/u0
ln -s /var/www/html/$FOLDER/${LOGIN}adm/  /var/www/u1
ln -s /var/www/html/$FOLDER/$STATS/ /var/www/u2
#

cat <<EOT > /var/www/html/$FOLDER/${LOGIN}adm/.htaccess
AuthType Basic
AuthName " "
AuthUserFile /var/www/html/$FOLDER/${LOGIN}adm/.passwd
Require valid-user 
EOT
htpasswd -cb /var/www/html/$FOLDER/${LOGIN}adm/.passwd $LOGIN $PASS
sed -i -r "s/xpass111/$MYSQL_ROOT_PASS/" $FOLDER/config.php
DB_NAME=`date +%s | sha256sum | base64 | head -c 16 ; echo`
sed -i -r "s/'DB_NAME/'$DB_NAME/" $FOLDER/config.php
sed -i -r "s/'DIR_PANEL/'${LOGIN}adm/" $FOLDER/config.php
sed -i -r "s/'DIR_STATS/'$STATS/" $FOLDER/config.php
sed -i -r "s/'DIR_MAIN/'$FOLDER/" $FOLDER/config.php

##### Connection problem?

ufw allow https
ufw allow 443
apachectl restart

## setup the panel

log_header "Executing install_cmd check"
echo "php /var/www/html/$FOLDER/${LOGIN}adm/INSTALL_cmd.php check"

php /var/www/html/$FOLDER/${LOGIN}adm/INSTALL_cmd.php check

if [ $? -ne 0 ]; then
	log_err "check FAILED; skipping testdb, install steps"
	exit
fi

log_header "Executing install_cmd testdb"
echo "php /var/www/html/$FOLDER/${LOGIN}adm/INSTALL_cmd.php testdb"
php /var/www/html/$FOLDER/${LOGIN}adm/INSTALL_cmd.php testdb

if [ $? -ne 0 ]; then
	log_err "testdb FAILED; skipping install step"
	exit
fi

log_header "Executing install_cmd install"
echo "php /var/www/html/$FOLDER/${LOGIN}adm/INSTALL_cmd.php install"
php /var/www/html/$FOLDER/${LOGIN}adm/INSTALL_cmd.php install

if [ $? -ne 0 ]; then
	log_err "install db FAILED"
	exit
fi

###### set expiration date
read -p "Set expiration date? y/[N]" CHK

if [ "$CHK" == "y" ]; then
	
	log_header "Set expiration date"
	while true
	do
		read -p "day:" day
		read -p "month:" month
		read -p "year:" year

		ts=$(date -d "${year}-${month}-${day} 23:59:59" +%s)
		
		if [ $? -eq 0 ]; then
			break
		else
			echo "bad format, try again"
		fi
	done

	echo $ts > /var/www/html/$FOLDER/static/expires.txt
	log_header "Expiration date set: $ts"

else
	log_header "Expiration date will be set in Builder [Force Sync]"
fi
######

echo .
log_header "SUCCESS Installation completed."

IP_FULL=`hostname -I` ; IP=`echo $IP_FULL | sed 's/ .*$//g'`
#log_info "now setup panel in browser"
log_header "Just for information: $IP_FULL"
log_header "/var/www/u0, u1, u2 aliases were created"
#echo "Install link: https://$IP/$FOLDER/${LOGIN}adm/INSTALL.php"
log_header "================= CLIENT ACCESS INFO ========================"
log_header ""
echo ""
echo "PANEL:https://$IP/$FOLDER/${LOGIN}adm/"
#echo "ANON_STATS:https://$IP/$FOLDER/$STATS/"
echo "AUTH:$LOGIN:$PASS"
echo "DB_URL:https://$IP/phpmyadmin"
echo "DB_AUTH:root:$MYSQL_ROOT_PASS"
echo "DB_NAME:$DB_NAME"
log_header "====================================================="

#~ echo "https://$IP/$FOLDER/$LOGIN\adm/"
#~ echo "Login: $LOGIN"
#~ echo "Password: $PASS"





